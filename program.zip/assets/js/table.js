$(document).ready(function () {

    $("#modalDaily").on('hidden.bs.modal', function () {
        $(this).find('form').trigger('reset');
    });

    // tabel log history
    $('#tabel-log').DataTable({
        "scrollX": true,
        responsive: true,
        "lengthMenu": [
            [10, 25, 50, 100, -1],
            [10, 25, 50, 100, "All"]
        ],
        dom: 'Plfrtip',
        // "autoWidth": true,
        columnDefs: [{
            searchPanes: {
                show: true,
                initCollapsed: true
            },
            targets: [1]
        }, {
            searchPanes: {
                show: true,
                initCollapsed: true
            },
            targets: [2]
        }, {
            searchPanes: {
                show: false
            },
            targets: [3]
        }, {
            searchPanes: {
                show: false
            },
            targets: [4]
        }, {
            searchPanes: {
                show: false
            },
            targets: [5]
        }, {
            searchPanes: {
                show: false
            },
            targets: [6]
        }],
    });

    // tabel laporan
    $('#tabel-data_laporan').DataTable({
        "scrollX": true,
        responsive: true,
        dom: 'Plfrtip',
        searchPanes: {
            cascadePanes: true
        },
        "lengthMenu": [
            [10, 25, 50, 100, -1],
            [10, 25, 50, 100, "All"]
        ],
        // "autoWidth": true,
        columnDefs: [{
            width: 120,
            targets: 1
        }, {
            width: 120,
            targets: 2
        }, {
            width: 350,
            targets: 3
        }, {
            width: 150,
            targets: 4
        }, {
            searchPanes: {
                show: true,
                initCollapsed: true,
                orderable: false
            },
            targets: [1,2]
        }, {
            searchPanes: {
                show: false
            },
            targets: [3, 4]
        }],
    });

    // tabel database laporan
    $('#tabel-database_laporan').DataTable({
        "scrollX": true,
        responsive: true,
        dom: 'PBlfrtip',
        buttons: [{
            extend: 'excelHtml5',
            footer: true

        }],
        "lengthMenu": [
            [10, 25, 50, 100, -1],
            [10, 25, 50, 100, "All"]
        ],
        "autoWidth": true,
        columnDefs: [{
            width: 150,
            targets: 1
        }, {
            width: 200,
            targets: 2
        }, {
            width: 250,
            targets: 3
        }, {
            searchPanes: {
                show: true,
                initCollapsed: true,
                orderable: false
            },
            targets: [1,2]
        }, {
            searchPanes: {
                show: false
            },
            targets: [3]
        }],
    });

});