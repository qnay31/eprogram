<nav class="stroke">
    <ul>
        <li>
            <a href="<?= $_SESSION["username"] ?>.php?id_forms=forms_laporan" class="active">Form</a>
        </li>
    </ul>
</nav>

<?php 

// die(var_dump($id_unik));

?>