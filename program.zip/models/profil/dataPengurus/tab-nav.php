<li class="nav-item">
    <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-program">Admin</button>
</li>

<li class="nav-item">
    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-logistik">Facebook Depok
        (<?= $pengurus_depok ?>)
    </button>
</li>

<li class="nav-item">
    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-humas">Facebook Bogor
        (<?= $pengurus_bogor ?>)</button>
</li>

<li class="nav-item">
    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-income">Instagram
        (<?= $pengurus_ins ?>)</button>
</li>