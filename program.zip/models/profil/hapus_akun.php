<?php 
session_start();

error_reporting(0);
require '../../function.php';

$akun     = $_GET["id_akun"];
$unik     = $_GET["id_key"];
$query    = mysqli_query($conn, "SELECT * FROM data_akun WHERE nomor_id = '$unik' AND nama_akun = '$akun'");
$data           = mysqli_fetch_assoc($query);
$nama_akun      = $data["nama_akun"];
$ip             = get_client_ip();
$date           = date("Y-m-d H:i:s");

// die(var_dump($hapus));
$query = mysqli_query($conn, "DELETE FROM `data_akun` WHERE nomor_id = '$unik' AND nama_akun = '$akun'");
$query2 = mysqli_query($conn, "DELETE FROM `income_media` WHERE nomor_id = '$unik' AND nama_akun = '$akun'");
$query3 = mysqli_query($conn, "DELETE FROM `laporan_media` WHERE nomor_id = '$unik' AND nama_akun = '$akun'");

// die(var_dump($query2));
$result2 = mysqli_query($conn, "INSERT INTO 2022_log_aktivity VALUES('', '$_SESSION[nama]', '$_SESSION[posisi]', '$ip', '$date', '$_SESSION[nama] Divisi $_SESSION[posisi] Telah Menghapus akun media sosial dengan nama akun $akun')");

if ($query == true && $query2 == true && $query3 == true) {
    echo "<script>
    alert('Akun Berhasil Dihapus');
    document.location.href = '../../admin/$_SESSION[username].php?id_profil=myProfil';
    </script>";
}  else {
    echo "<script>
    alert('Akun Tidak Berhasil Dihapus');
    document.location.href = '../../admin/$_SESSION[username].php?id_profil=myProfil';
    </script>";
}


?>