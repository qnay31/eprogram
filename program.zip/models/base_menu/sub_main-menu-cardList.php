<?php 
if ($_SESSION["id_pengurus"] == "ketua_yayasan") {
    $yatim   = mysqli_query($conn, "SELECT * FROM data_yatim ORDER BY `nama_yatim` ASC");

    $numYatim= $yatim -> num_rows;

} else {
    $yatim   = mysqli_query($conn, "SELECT * FROM data_yatim WHERE cabang = '$_SESSION[cabang]' ORDER BY `nama_yatim` ASC");

    $numYatim= $yatim -> num_rows;
}


// die(var_dump($$namaBaru[$n]));
?>
<!-- Card -->
<div class="col-xxl-12">
    <div class="card info-card customers-card">
        <div class="card-body">
            <h5 class="card-title">Data Yatim
                <?php if ($numYatim > 1) { ?>
                (<?= $numYatim ?>)
                <?php } ?>

            </h5>
            <div class="row">
                <!-- Card -->
                <!-- <?php 
                $no = 1;
                while ($data = $yatim -> fetch_assoc()) { ?> -->
                <div class="col-xxl-4 col-md-6">
                    <div class="card info-card customers-card">
                        <span class="card1">
                            <div class="card-body">
                                <h5 class="card-title">Yatim <?= $data["cabang"] ?>
                                </h5>

                                <div class="d-flex align-items-center">
                                    <div
                                        class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-person"></i>
                                    </div>
                                    <div class="ps-3">
                                        <span class="akun"> Nama : <?= ucwords($data["nama_yatim"]) ?>
                                        </span>
                                        <br>
                                        <span class="akun">Usia :
                                            <?php if ($data["tempatLahir"] == "") { ?>
                                            -

                                            <?php } else { ?>
                                            <?php 
                                                    $awal   = $data['tgl_lahir'];
                                                    $akhir  = date("Y-m-d");

                                                    $tanggal    = new DateTime($awal);
                                                    $today      = new DateTime($akhir);

                                                    $y = $today->diff($tanggal)->y;
                                                ?>

                                            <?= $y ?> Tahun
                                            <?php } ?>

                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="go-corner">
                                <div class="go-arrow">
                                    →
                                </div>
                            </div>
                        </span>
                        <a class="viewData"
                            href="<?= $_SESSION["username"] ?>.php?id_akun=<?= $data["nama_yatim"] ?>">Lihat
                            Perkembangan</a>
                    </div>
                </div>
                <!-- <?php } ?> -->
                <!-- End Card -->
            </div>
        </div>
    </div>
</div><!-- End Card -->